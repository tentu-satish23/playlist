FREE MUSIC WEBSITE STARTER KIT
================================

This ZIP does not contain commercial MP3 songs. It contains a starter downloader
and folder structure for collecting legally downloadable tracks for a website.

IMPORTANT
- Jamendo's catalog mainly contains independent music; it may not contain the
  popular Telugu/Hindi film songs you know.
- Create your own Jamendo developer account and use your own client_id:
  https://devportal.jamendo.com/signup
- Check each track's license and credit the artist as required.
- Jamendo API terms may restrict use to non-commercial projects unless separately
  licensed. Review current terms before publishing:
  https://devportal.jamendo.com/api_terms_of_use
- The downloader checks the API's audiodownload_allowed flag before downloading.
- Do not redistribute a track or use it commercially unless its license permits it.

QUICK START
1. Install Python 3.10+.
2. Install requests:  pip install requests
3. Set your Jamendo client ID:
   Windows CMD: set JAMENDO_CLIENT_ID=YOUR_CLIENT_ID
   macOS/Linux: export JAMENDO_CLIENT_ID=YOUR_CLIENT_ID
4. Run:
   python download_jamendo.py --query "ambient" --limit 5 --language English
5. Inspect the generated credits.csv and each track's license before using it.

Note: language is only a folder label here; the Jamendo API does not guarantee
that search results are actually sung in that language. Review tracks manually.
