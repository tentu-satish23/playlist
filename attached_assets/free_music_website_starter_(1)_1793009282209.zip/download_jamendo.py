#!/usr/bin/env python3
"""Download tracks from Jamendo only when the API says audio downloads are allowed.

Usage:
  python download_jamendo.py --query "ambient" --limit 5 --language English

Requires:
  pip install requests
  JAMENDO_CLIENT_ID environment variable from your own Jamendo developer account.
"""
import argparse
import csv
import os
import re
import sys
from pathlib import Path
import requests

API = "https://api.jamendo.com/v3.0/tracks/"

def safe_name(value):
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", value or "track")
    return re.sub(r"\s+", " ", value).strip()[:120] or "track"

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--query", required=True, help="Search terms, e.g. ambient, acoustic, Indian")
    parser.add_argument("--limit", type=int, default=5)
    parser.add_argument("--language", choices=["Telugu", "Hindi", "English"], default="English",
                        help="Folder label only; verify the actual language manually")
    args = parser.parse_args()

    client_id = os.getenv("JAMENDO_CLIENT_ID")
    if not client_id:
        sys.exit("Set JAMENDO_CLIENT_ID to your own Jamendo developer client ID first.")

    params = {
        "client_id": client_id,
        "format": "json",
        "limit": max(1, min(args.limit, 50)),
        "search": args.query,
        "audioformat": "mp32",
        "include": "licenses",
        "order": "popularity_total",
    }
    response = requests.get(API, params=params, timeout=30)
    response.raise_for_status()
    payload = response.json()
    if payload.get("headers", {}).get("status") != "success":
        sys.exit("Jamendo API returned an error: " + str(payload.get("headers", {})))

    tracks = payload.get("results", [])
    folder = Path("music") / args.language
    folder.mkdir(parents=True, exist_ok=True)
    credits_path = Path("credits.csv")
    new_rows = []

    for track in tracks:
        allowed = track.get("audiodownload_allowed")
        if allowed not in (True, 1, "true", "1"):
            print("Skipping (downloads not allowed):", track.get("name", "Unknown"))
            continue
        download_url = track.get("audiodownload")
        if not download_url:
            print("Skipping (no download URL):", track.get("name", "Unknown"))
            continue

        title = safe_name(track.get("name"))
        artist = safe_name(track.get("artist_name"))
        filename = f"{artist} - {title}.mp3"
        destination = folder / filename
        try:
            audio = requests.get(download_url, timeout=90, allow_redirects=True)
            audio.raise_for_status()
            content_type = audio.headers.get("Content-Type", "").lower()
            if "text/html" in content_type or len(audio.content) < 1024:
                print("Skipping suspicious/empty response:", filename)
                continue
            destination.write_bytes(audio.content)
            licenses = track.get("license_ccurl") or track.get("license_ccurl") or ""
            row = {
                "language_folder": args.language,
                "title": track.get("name", ""),
                "artist": track.get("artist_name", ""),
                "license_url": licenses,
                "track_page": track.get("shareurl", ""),
                "downloaded_file": str(destination),
            }
            new_rows.append(row)
            print("Downloaded:", destination)
        except requests.RequestException as exc:
            print("Download failed:", filename, "-", exc)

    fields = ["language_folder", "title", "artist", "license_url", "track_page", "downloaded_file"]
    write_header = not credits_path.exists()
    with credits_path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        if write_header:
            writer.writeheader()
        writer.writerows(new_rows)
    print(f"Finished. Downloaded {len(new_rows)} track(s). Review credits.csv and licenses before publishing.")

if __name__ == "__main__":
    main()
